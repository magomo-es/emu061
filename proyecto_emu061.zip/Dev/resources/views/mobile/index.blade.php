@extends('_layouts.mobile')

@section('pageTitle', 'Inici | Mobil emu061 - Emulador de Sistema d\'Emergències 061')

@section('pageContent')
@endsection




