@extends('_layouts.admin')

@section('pageTitle', 'Inici | Administració emu061 - Emulador de Sistema d\'Emergències 061')

@section('pageContent')
@endsection




