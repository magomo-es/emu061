@extends('_layouts.operator')

@section('pageTitle', 'Inici | Operador emu061 - Emulador de Sistema d\'Emergències 061')

@section('pageContent')
@endsection




