<!DOCTYPE html><!-- MAIN TEMPLATE -->
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('pageTitle'); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">

        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

        <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/css/all.css')); ?>">

        <!-- Styles -->
        <style></style>

    </head>

    <body>

        <nav class="navbar navbar-expand-lg bg-primary">

            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/img/logo.png')); ?>" style="max-height: 50px;" /></a>

            <h5 class="text-white px-4 m-0">emu061</h5>

            <div class="collapse navbar-collapse" id="navbarColor01">

              <ul class="navbar-nav mr-auto">

                <li class="nav-item">

                    <a class="nav-link text-white"  href="<?php echo e(url('/admin')); ?>" role="button">Adminintració</a>

                </li>

                <li class="nav-item">

                    <a class="nav-link text-white"  href="<?php echo e(url('/operator')); ?>" role="button">Operadors</a>

                  </li>

                  <li class="nav-item">

                    <a class="nav-link text-white"  href="<?php echo e(url('/mobile')); ?>" role="button">Mobils</a>

                  </li>

              </ul>

            </div>

        </nav>

        <?php echo $__env->make('_partials.userbox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container-fluid mt-3 mb-5"><?php echo $__env->yieldContent('pageContent'); ?></div>

    </body>


    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <?php echo $__env->yieldContent('pageModalScript'); ?>

</html>
<?php /**PATH X:\xampp\htdocs\00_Proyecto_emu061\emu061\Dev\resources\views/_layouts/main.blade.php ENDPATH**/ ?>