<?php $__env->startSection('pageTitle', 'Inici | Administració emu061 - Emulador de Sistema d\'Emergències 061'); ?>

<?php $__env->startSection('pageContent'); ?>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('_layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\xampp\htdocs\00_Proyecto_emu061\emu061\Dev\resources\views/admin/index.blade.php ENDPATH**/ ?>