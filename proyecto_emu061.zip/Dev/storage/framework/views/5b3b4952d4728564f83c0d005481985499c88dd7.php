<div class="dropdown" style="position: absolute; top: 0;right: 10px;z-index: 99;">

    <?php if(Auth::check()): ?>

    <button class="btn btn-warning dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->username); ?> <span class="caret"></span></button>
    <div class="dropdown-menu dropdown-menu-right">
        <?php if(Auth::user()->rols_id==1): ?><li><a class="dropdown-item" href="<?php echo e(url('admin')); ?>">Administració</a></li><?php endif; ?>
        <?php if(Auth::user()->rols_id==1 || Auth::user()->rols_id==2): ?><a class="dropdown-item" href="<?php echo e(url('operator')); ?>">CECOS</a><?php endif; ?>
        <?php if(Auth::user()->rols_id==1 || Auth::user()->rols_id==3): ?><a class="dropdown-item" href="<?php echo e(url('mobile')); ?>">Recursos</a><?php endif; ?>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="<?php echo e(action([App\Http\Controllers\UsuariController::class, 'logout'])); ?>">
            <i class="fa fa-sign-out" aria-hidden="true"></i> Sortir</a>
    </div>

    <?php else: ?>

    <a class="btn btn-danger" type="button" href="<?php echo e(url('/login')); ?>">
        <i class="fa fa-sign-in" aria-hidden="true"></i> Login
    </a>

    <?php endif; ?>

</div>
<?php /**PATH X:\xampp\htdocs\00_Proyecto_emu061\emu061\Dev\resources\views/_partials/userbox.blade.php ENDPATH**/ ?>